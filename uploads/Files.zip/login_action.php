<?php
session_start();
require_once 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Basic validation
    if (empty($username) || empty($password)) {
        die("Both username and password are required");
    }

    // Database connection
    $database = new Database();
    $conn = $database->getConnection();

    try {
        // Prepare SQL to fetch user
        $stmt = $conn->prepare("SELECT * FROM Users WHERE username = ?");
        $stmt->execute([$username]);
        
        // Check if user exists
        if ($stmt->rowCount() == 0) {
            die("Invalid username or password");
        }

        // Fetch user data
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verify password
        if (password_verify($password, $user['password'])) {
            // Login successful
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];

            // Update last login time
            $update_stmt = $conn->prepare("UPDATE Users SET last_login = NOW() WHERE user_id = ?");
            $update_stmt->execute([$user['user_id']]);

            // Redirect to dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            die("Invalid username or password");
        }
    } catch(PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>