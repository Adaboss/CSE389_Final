-- Total Notes for a User
SELECT COUNT(*) AS total_notes 
FROM Notes 
WHERE user_id = [current_user_id];

-- Shared Notes Count
SELECT COUNT(*) AS shared_notes 
FROM NoteShares 
WHERE shared_by_user_id = [current_user_id];

-- Collaborators Count
SELECT COUNT(DISTINCT shared_with_user_id) AS collaborators 
FROM NoteShares 
WHERE shared_by_user_id = [current_user_id];