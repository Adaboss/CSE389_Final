<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'db_connection.php';

// Database connection
$database = new Database();
$conn = $database->getConnection();

try {
    // Total Notes
    $total_notes_stmt = $conn->prepare("SELECT COUNT(*) AS total_notes FROM Notes WHERE user_id = ?");
    $total_notes_stmt->execute([$_SESSION['user_id']]);
    $total_notes = $total_notes_stmt->fetch(PDO::FETCH_ASSOC)['total_notes'];

    // Shared Notes
    $shared_notes_stmt = $conn->prepare("SELECT COUNT(*) AS shared_notes FROM NoteShares WHERE shared_by_user_id = ?");
    $shared_notes_stmt->execute([$_SESSION['user_id']]);
    $shared_notes = $shared_notes_stmt->fetch(PDO::FETCH_ASSOC)['shared_notes'];

    // Collaborators
    $collaborators_stmt = $conn->prepare("SELECT COUNT(DISTINCT shared_with_user_id) AS collaborators FROM NoteShares WHERE shared_by_user_id = ?");
    $collaborators_stmt->execute([$_SESSION['user_id']]);
    $collaborators = $collaborators_stmt->fetch(PDO::FETCH_ASSOC)['collaborators'];

    // Recent Notes
    $recent_notes_stmt = $conn->prepare("SELECT title, last_edited FROM Notes WHERE user_id = ? ORDER BY last_edited DESC LIMIT 5");
    $recent_notes_stmt->execute([$_SESSION['user_id']]);
    $recent_notes = $recent_notes_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Your existing dashboard CSS from dashboard.css -->
    <title>NoteShare - Dashboard</title>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar from your existing CSS -->
        <aside class="sidebar">
            <!-- ... existing sidebar code ... -->
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="dashboard-header">
                <h1 class="welcome-message">Welcome, <?php echo $_SESSION['username']; ?>!</h1>
            </header>

            <!-- Quick Stats -->
            <section class="quick-stats">
                <div class="stat-card">
                    <h3>Total Notes</h3>
                    <p><?php echo $total_notes; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Shared Notes</h3>
                    <p><?php echo $shared_notes; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Collaborators</h3>
                    <p><?php echo $collaborators; ?></p>
                </div>
            </section>

            <!-- Notes Section -->
            <section class="notes-section">
                <div class="notes-header">
                    <h2>Recent Notes</h2>
                    <button class="create-note-btn">+ Create Note</button>
                </div>
                <ul class="notes-list">
                    <?php foreach ($recent_notes as $note): ?>
                        <li>
                            <span><?php echo htmlspecialchars($note['title']); ?></span>
                            <span>Last edited: <?php echo date('d M Y, H:i', strtotime($note['last_edited'])); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        </main>
    </div>
</body>
</html>