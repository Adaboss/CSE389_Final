<?php
class Database {
    private $host = 'localhost';     // Database host
    private $db_name = 'noteshare';  // Your database name
    private $username = 'root';      // Database username
    private $password = '';          // Database password
    public $conn;

    // Create database connection
    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name, 
                $this->username, 
                $this->password
            );
            // Set the PDO error mode to exception
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            // Handle connection error
            echo "Connection error: " . $exception->getMessage();
            exit();
        }

        return $this->conn;
    }
}
?>