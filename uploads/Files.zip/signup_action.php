<?php
require_once 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Basic validation
    if (empty($username) || empty($email) || empty($password)) {
        die("All fields are required");
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Database connection
    $database = new Database();
    $conn = $database->getConnection();

    try {
        // Prepare SQL to check if username or email already exists
        $check_stmt = $conn->prepare("SELECT * FROM Users WHERE username = ? OR email = ?");
        $check_stmt->execute([$username, $email]);
        
        if ($check_stmt->rowCount() > 0) {
            die("Username or email already exists");
        }

        // Prepare SQL to insert new user
        $stmt = $conn->prepare("INSERT INTO Users (username, email, password) VALUES (?, ?, ?)");
        
        // Execute the statement
        if ($stmt->execute([$username, $email, $hashed_password])) {
            // Redirect to login page after successful signup
            header("Location: login.php?signup=success");
            exit();
        } else {
            die("Signup failed");
        }
    } catch(PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>